Flow Control:In runtime in which order stmt are executed is decided by Flow Control.
3 types of flow control:
1.Conditional stmt/ selection stmt: if, if-else, if-elif-else
  if x                        if x
  option1                      action1
 else                         else
   option2                       action2
                             elif x
                                 action3

2.Iterative stmt/loop: for,while (do while, switch stmt not available in python)

3.Transfer stmt: break.pass,continue